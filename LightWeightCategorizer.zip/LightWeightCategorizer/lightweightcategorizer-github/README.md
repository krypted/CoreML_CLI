# lightweightcategorizer
Python script for categorizing content using 3 different methods
